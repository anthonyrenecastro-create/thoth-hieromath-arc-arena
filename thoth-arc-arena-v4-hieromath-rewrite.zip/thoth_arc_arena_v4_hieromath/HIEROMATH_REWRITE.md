# Thoth ARC Arena — Hieromathematics + HRM Rewrite

This rewrite uses `thoth-arc-arena (4)` as the functional base and preserves its existing Gemini baseline, ARC puzzle loader, result comparison UI, benchmark history, AI-ecosystem code, and original `/api/arc/solve-hrm` endpoint. A new deterministic Hieromathematics execution path is added and made the active Twin B path in the ARC arena.

## Formal implementation

The runtime implements the six-field Hiero-object:

`H = <I, V, C, B, S, G>`

- `I` — identity
- `V` — value/content
- `C` — category/context/constraints
- `B` — behavior / legal participation
- `S` — current validity and bounded state
- `G` — representation/schema

ARC tasks are compiled into typed objects and explicit `IN`, `DEP`, `TR`, and `CAUSE` relations. Candidate transformations are not run immediately. Each operator first evaluates a compatibility predicate `Gamma`. Only candidates for which `Gamma = 1` are allowed to execute their numerical transform `Phi`.

The execution cycle is:

`parse -> resolve -> Gamma validate -> Phi transform -> verify -> commit -> ledger`

Rejected candidates remain visible in the Binary Semantic Ledger without contaminating the committed mathematical state.

## New files

- `src/types/hieromath.ts` — Hiero-object, relations, semantic graph, ledger, feature and metric types.
- `src/engine/hieromath.ts` — canonicalization, stable semantic signatures, object validity, graph builder, Binary Semantic Ledger.
- `src/engine/hieromathArc.ts` — ARC semantic feature extraction, typed operator contracts, semantic pruning, transactional commit, equal-capability brute-force reference.
- `scripts/benchmark-hieromath.ts` — legacy/equal-capability/Hieromathematics local benchmark.
- `benchmarks/*.json` — benchmark outputs produced during the rewrite.

## New API

`POST /api/arc/solve-hieromath`

Payload:

```json
{
  "puzzle": { "...": "ARC puzzle" },
  "maxRounds": 40
}
```

The response includes:

- predicted grid
- committed typed hypothesis
- surviving numerical candidates
- semantic graph
- accepted/rejected Binary Semantic Ledger events
- pre-compute pruning metrics
- kernel execution counts
- API/token metrics

The solver is deterministic and uses zero model API calls and zero tokens.

## Operator inventory

The rewrite currently includes six declared semantic operators:

1. Identity / no-change
2. Global semantic color mapping
3. Typed downward object transport
4. 2x2-seed diagonal propagation
5. Frame-scoped interior extraction
6. 90-degree coordinate transport

The operator inventory is deliberately small and explicit. It is not intended to imply broad ARC generality yet.

## Baseline from the supplied v4 app

The original deterministic mechanism phase was run directly from the supplied source with Gemini excluded.

| Puzzle | Legacy local mechanism result |
|---|---:|
| Red Dot Gravity | Fail — 75% cell accuracy |
| Diagonal Mirror | Fail — 75% cell accuracy |
| Color Flood | Exact |
| Bounding Box | Exact |
| **Total** | **2/4 exact (50%)** |

Mean cell accuracy: **87.5%**.

A 100,000-solve microbenchmark of the legacy mechanism inventory measured approximately **803.9 ms total / 0.00804 ms per solve** in one run. This is not an apples-to-apples performance comparison because the legacy inventory does not contain two of the transformations implemented in the new solver.

## Controlled equal-capability comparison

To isolate semantic pruning from mechanism capability, the rewrite also includes `solveARCBruteForceReference`. It uses the exact same six transformation kernels as the Hieromathematics solver but evaluates all six candidates numerically instead of applying `Gamma` pruning first.

Both equal-capability paths solve all four bundled tasks exactly:

| Measure | Conventional brute-force reference | Hieromathematics |
|---|---:|---:|
| Exact puzzles | 4/4 | 4/4 |
| Candidate kernels per puzzle | 6 | 1 |
| Total candidate kernels, 4 puzzles | 24 | 4 |
| Candidates pruned before numerical candidate evaluation | 0 | 20/24 |
| Kernel-count reduction | — | **83.3%** |

In one 100,000-solve comparison run, the equal-capability reference measured ~**0.02945 ms/solve** and the Hieromathematics path ~**0.02585 ms/solve**. A smaller repeated test (5 repeats of 20,000 solves) produced a median of **604.36 ms** for the equal-capability reference and **542.16 ms** for the Hieromathematics path, about **10.3% lower median wall time** in that run set.

These wall-clock numbers are preliminary. The puzzles are extremely small; JIT compilation, garbage collection, graph/ledger allocation, and machine noise are a large fraction of runtime. The stronger result at this stage is structural: the same answers were obtained while dispatching 4 candidate numerical kernels rather than 24. Larger and external ARC tasks are required before making a performance or scaling claim.

## Important scientific control

The increase from 2/4 to 4/4 versus the legacy local solver is **not evidence by itself that Hieromathematics improved reasoning**. The new inventory includes gravity and diagonal operators that the legacy inventory lacked or had unfinished. The equal-capability reference exists specifically to control for that confound.

The falsifiable question is therefore not "does the rewritten app solve these four examples?" It is:

> With the same candidate transformation inventory and the same required output tolerance, can semantic compatibility and dependency structure consistently reject unnecessary numerical work early enough to offset their own overhead on larger workloads?

That is the benchmark this rewrite is designed to support.

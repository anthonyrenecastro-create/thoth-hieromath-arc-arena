# Thoth ARC Twin Arena — Hieromathematics + HRM

A comparative ARC reasoning arena built from the supplied Thoth ARC Arena v4 application.

The application now compares:

- **Twin A — Gemini Baseline:** the original single-pass Gemini ARC solver.
- **Twin B — Hieromathematics + HRM:** a deterministic semantic-compiler path using typed Hiero-objects, explicit semantic relations, `Gamma` validate-before-compute compatibility, `Phi` transformations, transactional commit, and a Binary Semantic Ledger.

The original HRM/AI-ecosystem code remains in the repository. The original `/api/arc/solve-hrm` route is preserved for compatibility; the ARC arena UI now calls `/api/arc/solve-hieromath` for Twin B.

## Run locally

Prerequisites: Node.js 20+.

```bash
npm install
cp .env.example .env.local
# GEMINI_API_KEY is optional for the Hieromathematics path.
npm run dev
```

The Hieromathematics solver itself requires no model API key.

## Benchmark

```bash
npm run benchmark:hieromath
```

This runs three local paths:

1. the legacy v4 mechanism inventory,
2. an equal-capability conventional brute-force reference using all six new kernels,
3. the Hieromathematics validate-before-compute solver using the same six kernels.

See `HIEROMATH_REWRITE.md` and `benchmarks/` for the recorded baseline and controlled comparison.

## Key implementation files

- `src/types/hieromath.ts`
- `src/engine/hieromath.ts`
- `src/engine/hieromathArc.ts`
- `src/components/HRMSolverPanel.tsx`
- `server.ts`
- `scripts/benchmark-hieromath.ts`

## Current scope

The bundled four-puzzle test is a development harness, not an ARC benchmark claim. The semantic operator vocabulary is intentionally small. The next scientific step is to import a much larger external ARC task set, freeze an equal mechanism inventory for both paths, and compare correctness, candidate kernels, visited cells/states, wall time, memory, and ledger overhead under repeated seeded runs.

import React from 'react';
import { BaselineSolverResponse, HRMSolverResponse, ARCGrid, ARCBenchmarkRecord } from '../types/arc';
import { gridsEqual, cellAccuracy } from '../engine/arcEvaluation';

interface ComparisonScoreboardProps {
  baseline: BaselineSolverResponse | null;
  hrm: HRMSolverResponse | null;
  expectedGrid?: ARCGrid;
  history?: ARCBenchmarkRecord[];
}

export const ComparisonScoreboard: React.FC<ComparisonScoreboardProps> = ({
  baseline,
  hrm,
  expectedGrid,
  history = []
}) => {
  if (!baseline || !hrm) return null;

  const bExact = expectedGrid ? gridsEqual(baseline.predictedOutput, expectedGrid) : null;
  const hExact = expectedGrid ? gridsEqual(hrm.predictedOutput, expectedGrid) : null;

  const bAcc = expectedGrid ? cellAccuracy(baseline.predictedOutput, expectedGrid) : 100;
  const hAcc = expectedGrid ? cellAccuracy(hrm.predictedOutput, expectedGrid) : 100;

  const speedWinner = baseline.metrics.latencyMs! < hrm.metrics.latencyMs! ? 'Twin A (Baseline)' : 'Twin B (HRM)';
  const tokenWinner = baseline.metrics.totalTokens < hrm.metrics.totalTokens ? 'Twin A (Baseline)' : 'Twin B (HRM)';

  let correctnessWinner = 'Tie';
  if (bExact !== null && hExact !== null) {
    if (bExact && !hExact) correctnessWinner = 'Twin A (Baseline)';
    else if (!bExact && hExact) correctnessWinner = 'Twin B (HRM)';
    else if (bAcc > hAcc) correctnessWinner = 'Twin A (Baseline)';
    else if (hAcc > bAcc) correctnessWinner = 'Twin B (HRM)';
  }

  const overallWinner = hExact && !bExact ? 'Twin B (HRM)' : bExact && !hExact ? 'Twin A (Baseline)' : hAcc >= bAcc ? 'Twin B (HRM)' : 'Twin A (Baseline)';

  // Calculate cumulative win tally from history
  let twinAWins = 0;
  let twinBWins = 0;
  if (history.length > 0) {
    history.forEach(rec => {
      if (rec.winner.overall.includes('Twin A')) twinAWins++;
      else if (rec.winner.overall.includes('Twin B')) twinBWins++;
    });
  } else {
    if (overallWinner.includes('Twin A')) twinAWins++;
    else twinBWins++;
  }

  return (
    <div className="bg-zinc-900/95 border border-zinc-800 rounded-2xl p-5 shadow-xl space-y-4">
      <div className="flex items-center justify-between border-b border-zinc-800 pb-3 flex-wrap gap-2">
        <h3 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
          Benchmark Comparison & Scoreboard (Aligned Output)
        </h3>
        <div className="flex items-center gap-3 flex-wrap">
          <span className="text-xs font-mono px-3 py-1 rounded-lg bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
            Rounds Played: <strong className="text-white">{hrm.reasoningRounds} / 40</strong>
          </span>
          <span className="text-xs font-mono px-3 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-semibold">
            Match Score Tally — Twin A: {twinAWins} | Twin B: {twinBWins}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-zinc-950/70 p-3.5 rounded-xl border border-zinc-800 flex flex-col justify-between">
          <span className="text-[10px] uppercase font-mono text-zinc-500">Correctness / Accuracy</span>
          <span className="text-sm font-bold text-cyan-300 mt-1">{correctnessWinner}</span>
          <div className="text-[10px] text-zinc-400 mt-1 flex justify-between font-mono">
            <span>A: {bAcc}%</span>
            <span className="text-cyan-400">B: {hAcc}%</span>
          </div>
        </div>

        <div className="bg-zinc-950/70 p-3.5 rounded-xl border border-zinc-800 flex flex-col justify-between">
          <span className="text-[10px] uppercase font-mono text-zinc-500">Speed (Latency)</span>
          <span className="text-sm font-bold text-indigo-300 mt-1">{speedWinner}</span>
          <div className="text-[10px] text-zinc-400 mt-1 flex justify-between font-mono">
            <span>A: {baseline.metrics.latencyMs}ms</span>
            <span className="text-indigo-400">B: {hrm.metrics.latencyMs}ms</span>
          </div>
        </div>

        <div className="bg-zinc-950/70 p-3.5 rounded-xl border border-zinc-800 flex flex-col justify-between">
          <span className="text-[10px] uppercase font-mono text-zinc-500">Token Efficiency</span>
          <span className="text-sm font-bold text-amber-300 mt-1">{tokenWinner}</span>
          <div className="text-[10px] text-zinc-400 mt-1 flex justify-between font-mono">
            <span>A: {baseline.metrics.totalTokens}t</span>
            <span className="text-amber-400">B: {hrm.metrics.totalTokens}t</span>
          </div>
        </div>

        <div className="bg-zinc-950/70 p-3.5 rounded-xl border border-zinc-800 flex flex-col justify-between">
          <span className="text-[10px] uppercase font-mono text-zinc-500">Rounds & Win Tally</span>
          <span className="text-sm font-bold text-emerald-300 mt-1">A: {twinAWins} — B: {twinBWins}</span>
          <div className="text-[10px] text-zinc-400 mt-1 flex justify-between font-mono">
            <span>Rounds:</span>
            <span className="text-emerald-400">{hrm.reasoningRounds} Iterations</span>
          </div>
        </div>
      </div>
    </div>
  );
};


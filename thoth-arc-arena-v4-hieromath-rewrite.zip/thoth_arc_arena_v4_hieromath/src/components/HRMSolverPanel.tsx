import React, { useMemo, useState } from 'react';
import { HRMSolverResponse } from '../types/arc';
import { ARCGridView } from './ARCGridView';

interface HRMSolverPanelProps {
  result: HRMSolverResponse | null;
  isRunning: boolean;
}

export const HRMSolverPanel: React.FC<HRMSolverPanelProps> = ({ result, isRunning }) => {
  const [viewMode, setViewMode] = useState<'summary' | 'candidates' | 'ledger'>('summary');
  const hm = result?.metrics?.hieromath;
  const ledger = result?.binarySemanticLedger || [];
  const verifiedCount = useMemo(() => ledger.filter(e => e.status === 'VERIFIED').length, [ledger]);

  return (
    <div className="bg-zinc-900/90 border border-cyan-500/30 rounded-2xl p-5 shadow-xl shadow-cyan-500/5 flex flex-col justify-between space-y-4 h-full">
      <div className="flex items-center justify-between border-b border-zinc-800 pb-3 flex-wrap gap-2">
        <div>
          <span className="text-[10px] font-mono tracking-wider uppercase px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
            Twin B — Hieromathematics + HRM
          </span>
          <h3 className="text-base font-bold text-zinc-100 mt-1">Semantic Compiler / Validated Execution</h3>
          <p className="text-[10px] text-zinc-500 mt-1 font-mono">H=&lt;I,V,C,B,S,G&gt; → Γ → Φ → verify → commit → Binary Semantic Ledger</p>
        </div>
        {isRunning ? (
          <span className="flex items-center gap-1.5 text-xs text-amber-400 font-medium">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
            Compiling semantics...
          </span>
        ) : result ? (
          <div className="flex items-center gap-1.5">
            {(['summary','candidates','ledger'] as const).map(mode => (
              <button
                key={mode}
                onClick={() => setViewMode(mode)}
                className={`text-[10px] px-2 py-1 rounded-lg font-mono transition ${viewMode === mode ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'bg-zinc-800 text-zinc-400 border border-zinc-800'}`}
              >
                {mode === 'summary' ? 'Summary' : mode === 'candidates' ? `Candidates (${result.hypothesesLedger?.length || 0})` : `Ledger (${ledger.length})`}
              </button>
            ))}
          </div>
        ) : (
          <span className="text-xs text-zinc-500 font-medium">Ready</span>
        )}
      </div>

      {isRunning ? (
        <div className="py-20 flex flex-col items-center justify-center space-y-3 flex-1">
          <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-xs text-zinc-400 font-mono">Resolving semantic graph and validating operators before numerical execution...</p>
        </div>
      ) : result ? (
        <div className="space-y-4 flex-1 flex flex-col justify-between">
          {viewMode === 'summary' && (
            <div className="space-y-4">
              <div className="bg-zinc-950/70 border border-zinc-800 rounded-xl p-3 flex flex-col items-center">
                <span className="text-xs font-medium text-zinc-400 mb-2">Committed Test Grid</span>
                <ARCGridView grid={result.predictedOutput} size="lg" />
              </div>

              <div className="space-y-2 bg-zinc-950/50 p-3 rounded-xl border border-cyan-500/20">
                <div className="flex justify-between gap-2 items-start">
                  <div>
                    <span className="text-xs font-semibold text-cyan-300">
                      {result.committedHypothesis?.name || 'No candidate committed'}
                    </span>
                    <p className="text-[10px] text-zinc-500 font-mono mt-0.5">
                      {result.committedHypothesis?.semanticSignature || 'fallback'}
                    </p>
                  </div>
                  <span className="text-[10px] font-mono bg-cyan-500/10 text-cyan-400 px-2 py-0.5 rounded border border-cyan-500/30">
                    Confidence: {Math.round((result.committedHypothesis?.confidence || 0) * 100)}%
                  </span>
                </div>
                <p className="text-xs text-zinc-300 leading-relaxed">
                  {result.committedHypothesis?.description || 'No semantically admissible transformation survived validation.'}
                </p>
                {result.committedHypothesis?.ruleSteps && (
                  <ul className="text-xs text-zinc-400 space-y-1 pl-4 list-disc font-mono pt-1">
                    {result.committedHypothesis.ruleSteps.map((step, idx) => <li key={idx}>{step}</li>)}
                  </ul>
                )}
              </div>

              {hm && (
                <div className="grid grid-cols-2 gap-2 text-center">
                  <div className="bg-zinc-950/60 border border-zinc-800 rounded-lg p-2">
                    <span className="block text-[10px] text-zinc-500">Γ Pruned Before Compute</span>
                    <span className="font-mono text-sm text-emerald-400">{hm.candidatesPrunedBeforeCompute}/{hm.candidatesDeclared}</span>
                  </div>
                  <div className="bg-zinc-950/60 border border-zinc-800 rounded-lg p-2">
                    <span className="block text-[10px] text-zinc-500">Numerical Kernels Executed</span>
                    <span className="font-mono text-sm text-cyan-300">{hm.kernelsExecuted}</span>
                  </div>
                  <div className="bg-zinc-950/60 border border-zinc-800 rounded-lg p-2">
                    <span className="block text-[10px] text-zinc-500">Verified Candidates</span>
                    <span className="font-mono text-sm text-cyan-300">{verifiedCount}</span>
                  </div>
                  <div className="bg-zinc-950/60 border border-zinc-800 rounded-lg p-2">
                    <span className="block text-[10px] text-zinc-500">Semantic Graph</span>
                    <span className="font-mono text-sm text-zinc-200">{hm.semanticNodes}N / {hm.semanticRelations}E</span>
                  </div>
                </div>
              )}
            </div>
          )}

          {viewMode === 'candidates' && (
            <div className="space-y-2 max-h-[430px] overflow-y-auto pr-1">
              {(result.hypothesesLedger || []).map((h, i) => (
                <div key={h.id || i} className={`p-3 rounded-xl border ${result.committedHypothesis?.id === h.id ? 'border-cyan-500/50 bg-cyan-500/5' : 'border-zinc-800 bg-zinc-950/60'}`}>
                  <div className="flex justify-between gap-3">
                    <div>
                      <p className="text-xs font-semibold text-zinc-200">{h.name}</p>
                      <p className="text-[10px] text-zinc-500 font-mono">{h.proposer}</p>
                    </div>
                    <div className="text-right text-[10px] font-mono">
                      <p className="text-cyan-300">Train exact: {h.trainingExactMatches}</p>
                      <p className="text-zinc-500">Cell acc: {h.trainingCellAccuracy ?? 0}%</p>
                    </div>
                  </div>
                  <p className="text-[11px] text-zinc-400 mt-2">{h.description}</p>
                </div>
              ))}
              {(!result.hypothesesLedger || result.hypothesesLedger.length === 0) && <p className="text-xs text-zinc-500">No numerical candidate survived Γ compatibility.</p>}
            </div>
          )}

          {viewMode === 'ledger' && (
            <div className="space-y-1.5 max-h-[430px] overflow-y-auto pr-1 font-mono">
              {ledger.map((e) => (
                <div key={e.sequence} className="bg-zinc-950/70 border border-zinc-800 rounded-lg p-2.5">
                  <div className="flex justify-between gap-2 text-[10px]">
                    <span className={e.status.includes('REJECTED') ? 'text-amber-400' : e.status === 'COMMITTED' || e.status === 'VERIFIED' ? 'text-emerald-400' : 'text-cyan-300'}>
                      #{e.sequence} {e.status}
                    </span>
                    <span className="text-zinc-500">{e.operatorId}</span>
                  </div>
                  <p className="text-[10px] text-zinc-400 mt-1 font-sans leading-relaxed">{e.reason}</p>
                </div>
              ))}
            </div>
          )}

          <div className="grid grid-cols-3 gap-2 pt-3 border-t border-zinc-800 text-center mt-auto">
            <div className="bg-zinc-950/50 p-2 rounded-lg border border-zinc-800">
              <span className="text-[10px] text-zinc-500 block">Latency / Budget</span>
              <span className="text-xs font-mono font-semibold text-zinc-200">{result.metrics.latencyMs || 0}ms ({result.reasoningRounds})</span>
            </div>
            <div className="bg-zinc-950/50 p-2 rounded-lg border border-zinc-800">
              <span className="text-[10px] text-zinc-500 block">API Calls</span>
              <span className="text-xs font-mono font-semibold text-zinc-200">{result.metrics.apiCalls}</span>
            </div>
            <div className="bg-zinc-950/50 p-2 rounded-lg border border-zinc-800">
              <span className="text-[10px] text-zinc-500 block">Tokens</span>
              <span className="text-xs font-mono font-semibold text-zinc-200">{result.metrics.totalTokens}</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="py-20 flex flex-col items-center justify-center text-center text-zinc-500 space-y-2 flex-1">
          <p className="text-xs">Run both twins. Twin B will compile ARC structure into typed semantic objects, prune invalid operators, and commit a ledgered result.</p>
        </div>
      )}
    </div>
  );
};

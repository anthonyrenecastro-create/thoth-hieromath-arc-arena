export type ARCColor = number;
export type ARCGrid = ARCColor[][];

export interface ARCExample {
  input: ARCGrid;
  output?: ARCGrid;
  expectedOutput?: ARCGrid;
}

export interface ARCPuzzle {
  id: string;
  name: string;
  description: string;
  source: string;
  training: ARCExample[];
  test: ARCExample[];
}

export interface HieromathMetricSummary {
  candidatesDeclared: number;
  candidatesPrunedBeforeCompute: number;
  kernelsExecuted: number;
  trainingPairsEvaluated: number;
  estimatedCellsAvoided: number;
  ledgerEvents: number;
  semanticNodes: number;
  semanticRelations: number;
}

export interface SolverMetrics {
  latencyMs: number;
  apiCalls: number;
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
  startedAt?: number;
  completedAt?: number;
  reasoningRounds?: number;
  hypothesesGenerated?: number;
  hypothesesRejected?: number;
  revisions?: number;
  trainingExactMatch?: boolean;
  validGrid?: boolean;
  error?: string;
  hieromath?: HieromathMetricSummary;
}

export interface BaselineSolverResponse {
  predictedOutput: ARCGrid;
  ruleSummary: string;
  confidence: number;
  reasoningSteps: string[];
  metrics: SolverMetrics;
}

export interface TransformationHypothesis {
  id: string;
  name: string;
  description: string;
  confidence: number;
  trainingExactMatches: number;
  trainingCellAccuracy?: number;
  ruleSteps?: string[];
  proposer?: string;
  semanticSignature?: string;
  preservation?: string[];
  changed?: string[];
}

export interface HieroLedgerEventView {
  sequence: number;
  status: string;
  operatorId: string;
  objectIds: string[];
  reason: string;
  gamma?: 0 | 1;
  trainingExactMatches?: number;
  trainingCellAccuracy?: number;
  semanticSignature?: string;
}

export interface HieroGraphView {
  nodes: unknown[];
  relations: unknown[];
}

export interface HRMSolverResponse {
  predictedOutput: ARCGrid;
  reasoningRounds: number;
  committedHypothesis: TransformationHypothesis | null;
  hypothesesLedger: TransformationHypothesis[];
  metrics: SolverMetrics;
  semanticGraph?: HieroGraphView;
  binarySemanticLedger?: HieroLedgerEventView[];
  solverType?: string;
}

export interface ARCBenchmarkRecord {
  runId: string;
  timestamp: string;
  puzzleId: string;
  model: string;
  seed: number;
  mode: string;
  baselineBudgetMode: string;
  baseline: SolverMetrics;
  hrm: SolverMetrics;
  winner: {
    correctness: string;
    speed: string;
    apiEfficiency: string;
    tokenEfficiency: string;
    overall: string;
  };
}

export type NodeId = string;

export interface NodeGeometry {
  x: number;
  y: number;
  z?: number;
  [key: string]: any;
}

export interface Vector2D {
  x: number;
  y: number;
  [key: string]: any;
}

export interface Contribution {
  mechanismId: string;
  mechanismName?: string;
  targetNodeId?: NodeId;
  delta?: number;
  reasoning?: string;
  confidence?: number;
  activationStrength?: number;
  diagnostics?: any;
  selfEvolutionProposals?: any[];
  fieldDeltas?: Record<string, number>;
  proposedEvents?: any[];
  memoryModifications?: any;
  resourceAdjustments?: any;
  [key: string]: any;
}

export interface StructuralEvent {
  type: string;
  targetId?: string;
  nodeId?: string;
  parameters?: Record<string, any>;
  [key: string]: any;
}

export interface MemoryState {
  nodes?: MemoryNode[];
  [key: string]: any;
}

export interface LedgerEntry {
  id: string;
  step: number;
  timestamp: string;
  contributions: Contribution[];
  acceptedContributions?: Contribution[];
  winningMechanismId: string;
  stateHash: string;
  summary: string;
  [key: string]: any;
}

export interface PerceptualObservation {
  sourceId?: string;
  content?: string;
  salience?: number;
  timestamp?: number;
  associatedNodeIds?: string[];
  type?: string;
  [key: string]: any;
}

export interface RuntimeHealthState {
  isHealthy?: boolean;
  stabilityScore?: number;
  entropy?: number;
  stress?: number;
  warnings?: string[];
  [key: string]: any;
}

export interface CreditAssignment {
  mechanismId: string;
  credit?: number;
  reason?: string;
  reward?: number;
  blame?: number;
  [key: string]: any;
}

export interface ConsequenceEvaluation {
  actionId?: string;
  projectedDelta?: number;
  riskScore?: number;
  approved?: boolean;
  reason?: string;
  creditAssignments?: CreditAssignment[];
  goalProgressDelta?: number;
  predictionError?: number;
  causalConfidence?: number;
  [key: string]: any;
}

export interface MemoryNode {
  id: string;
  type: string;
  content: string;
  salience: number;
  associatedNodeIds: NodeId[];
  timestamp: number;
  [key: string]: any;
}

export interface MechanismReputation {
  mechanismId: string;
  reputationScore?: number;
  totalProposals?: number;
  acceptedProposals?: number;
  successRate?: number;
  failureRate?: number;
  isRetired?: boolean;
  isSuspended?: boolean;
  vetoedCount?: number;
  consecutiveFailures?: number;
  hallucinationHistory?: number[];
  trustScore?: number;
  totalContributions?: number;
  acceptedCount?: number;
  predictionAccuracy?: number;
  confidence?: number;
  resourceEfficiency?: number;
  [key: string]: any;
}

export interface HRMNode {
  id: NodeId;
  label: string;
  type: string;
  value: number;
  baseline: number;
  geometry: NodeGeometry;
  metadata?: Record<string, any>;
  [key: string]: any;
}

export interface HRMWorldState {
  step: number;
  timestamp: number;
  activeGoal: string;
  globalStress: number;
  globalEntropy: number;
  stress?: number;
  uncertainty?: number;
  safeModeActive?: boolean;
  attentionFocusNodeId: NodeId;
  nodes: Record<NodeId, HRMNode>;
  observation: Record<string, any>;
  aiEcosystem?: any;
  topology?: {
    nodes: any[];
    edges: any[];
    adjacency?: any;
    [key: string]: any;
  };
  cognition?: any;
  guidance?: {
    riskTolerance: number;
    [key: string]: any;
  };
  resources?: {
    structuralEventBudget: number;
    [key: string]: any;
  };
  field?: {
    values: Record<string, number>;
    [key: string]: any;
  };
  memory?: MemoryState;
  metadata?: {
    step: number;
    timestamp: number;
    stateHash: string;
    [key: string]: any;
  };
  [key: string]: any;
}

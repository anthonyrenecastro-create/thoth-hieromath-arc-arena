import type { ARCGrid } from './arc';

/**
 * Canonical six-field Hiero-object from Hieromathematics 2.0.
 * H = <I, V, C, B, S, G>
 */
export interface HieroObject<T = unknown> {
  I: string; // identity
  V: T;      // value / content
  C: HieroContext;
  B: HieroBehavior;
  S: HieroState;
  G: HieroRepresentation;
  provenance?: HieroProvenance;
}

export interface HieroContext {
  domain: string;
  type: string;
  units?: string;
  scope?: string;
  constraints?: string[];
  tags?: string[];
}

export interface HieroBehavior {
  classes: string[];
  mutable: boolean;
  recursive?: boolean;
}

export interface HieroState {
  valid: boolean;
  active: boolean;
  bounded: boolean;
  constraintSatisfied: boolean;
  deterministic: boolean;
}

export interface HieroRepresentation {
  kind: 'arc_grid' | 'arc_puzzle' | 'feature' | 'mechanism' | 'candidate' | 'scalar' | 'record';
  schema: string;
  version: number;
}

export interface HieroProvenance {
  sourceIds: string[];
  ruleId?: string;
  priorStateId?: string;
}

export type HieroRelationCode = 'SEQ' | 'CAUSE' | 'IN' | 'DEP' | 'EQV' | 'OPP' | 'TR' | 'REC' | 'HIER' | 'FB';

export interface HieroRelation {
  id: string;
  r: HieroRelationCode;
  from: string;
  to: string;
  kappa?: Record<string, unknown>;
}

export interface HieroGraph {
  nodes: HieroObject[];
  relations: HieroRelation[];
}

export type HieroLedgerStatus =
  | 'PARSED'
  | 'RESOLVED'
  | 'REJECTED_COMPATIBILITY'
  | 'ACCEPTED_CANDIDATE'
  | 'REJECTED_TRAINING'
  | 'VERIFIED'
  | 'COMMITTED'
  | 'FALLBACK';

export interface HieroLedgerEvent {
  sequence: number;
  status: HieroLedgerStatus;
  operatorId: string;
  objectIds: string[];
  reason: string;
  gamma?: 0 | 1;
  preservation?: string[];
  changed?: string[];
  trainingExactMatches?: number;
  trainingCellAccuracy?: number;
  semanticSignature?: string;
  timestampLogical: number;
}

export interface HieroCompatibilityResult {
  ok: boolean;
  reasons: string[];
  signature: string;
  estimatedCellsAvoided?: number;
}

export interface ARCStructuralFeatures {
  inputShape: [number, number];
  outputShape?: [number, number];
  sameShape: boolean;
  outputSmaller: boolean;
  outerFrameUniform: boolean;
  outerFrameColor: number | null;
  nonZeroCountInput: number;
  nonZeroCountOutput?: number;
  colorMapConsistent: boolean;
  changedCells: number;
  activeBoundingBox?: [number, number, number, number];
  topLeftQuadrantOnly: boolean;
  hasFullUniformRow: boolean;
  fullUniformRows: Array<{ row: number; color: number }>;
}

export interface HieroCandidate {
  operatorId: string;
  name: string;
  description: string;
  predictedTrainingOutputs: ARCGrid[];
  predictedTestOutput: ARCGrid;
  trainingExactMatches: number;
  trainingCellAccuracy: number;
  confidence: number;
  complexity: number;
  semanticSignature: string;
  ruleSteps: string[];
  preservation: string[];
  changed: string[];
}

export interface HieroExecutionMetrics {
  candidatesDeclared: number;
  candidatesPrunedBeforeCompute: number;
  kernelsExecuted: number;
  trainingPairsEvaluated: number;
  estimatedCellsAvoided: number;
  ledgerEvents: number;
  semanticNodes: number;
  semanticRelations: number;
}

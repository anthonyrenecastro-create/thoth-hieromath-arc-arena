export type CapabilityDimension =
  | 'language_understanding'
  | 'mathematical_reasoning'
  | 'software_development'
  | 'scientific_discovery'
  | 'long_term_planning'
  | 'memory'
  | 'multimodal_perception'
  | 'robotics_control'
  | 'social_reasoning'
  | 'self_correction'
  | 'autonomous_tool_use'
  | 'agent_coordination'
  | 'model_to_model_communication'
  | 'continuous_learning'
  | 'recursive_improvement';

export interface CapabilityMetrics {
  level: number;
  growthRatePerCycle: number;
  reliability: number;
  economicViability: number;
  [key: string]: any;
}

export interface AISystemTwin {
  id: string;
  label: string;
  modelFamily?: string;
  architecture?: string;
  parameterScaleB?: number;
  contextCapacityTokens?: number;
  trainingMethod?: string;
  inferenceCostPer1kTokensUsd?: number;
  reasoningPerformance?: number;
  toolUseAbility?: number;
  memoryArchitecture?: string;
  autonomyLevel?: number;
  safetyControls?: number;
  reliability?: number;
  hallucinationRate?: number;
  deploymentEnvironment?: string;
  capabilityImprovementRate?: number;
  capabilities?: Record<CapabilityDimension, CapabilityMetrics>;
  [key: string]: any;
}

export interface InfrastructureTwin {
  id: string;
  label: string;
  gpuAvailabilityIndex?: number;
  semiconductorProductionIndex?: number;
  memoryBandwidthTbps?: number;
  energyDemandMw?: number;
  coolingCapacityMw?: number;
  dataCenterExpansionRate?: number;
  cloudAvailabilityIndex?: number;
  networkCapacityTbps?: number;
  hardwareEfficiencyGainRate?: number;
  edgeAdoptionIndex?: number;
  supplyChainConstraintIndex?: number;
  manufacturingConcentrationRisk?: number;
  [key: string]: any;
}

export interface OrganizationTwin {
  id: string;
  label: string;
  orgType?: string;
  capitalUsdBn?: number;
  computeCapacityExaFLOPs?: number;
  researchTalentIndex?: number;
  strategicGoal?: string;
  modelAccessLevel?: number;
  proprietaryDataAdvantage?: number;
  safetyCulture?: number;
  publicationAggressiveness?: number;
  competitivePressure?: number;
  regulatoryExposure?: number;
  partnershipNetworkStrength?: number;
  releaseAggressiveness?: number;
  [key: string]: any;
}

export interface DataEcosystemTwin {
  id: string;
  label: string;
  dataAvailabilityIndex?: number;
  dataQualityIndex?: number;
  syntheticDataShare?: number;
  copyrightRestrictionIntensity?: number;
  privacyConstraintIntensity?: number;
  multilingualCoverage?: number;
  contaminationRisk?: number;
  feedbackLoopPressure?: number;
  modelContentSaturation?: number;
  humanContentRefreshRate?: number;
  [key: string]: any;
}

export interface PolicyTwin {
  id: string;
  label: string;
  computeThresholdStrictness?: number;
  licensingStrictness?: number;
  releaseRestrictionIntensity?: number;
  dataRegulationIntensity?: number;
  safetyEvalMandateStrength?: number;
  transparencyRequirementStrength?: number;
  internationalCoordinationIndex?: number;
  liabilityPressure?: number;
  evasionPressure?: number;
  [key: string]: any;
}

export interface HumanInstitutionTwin {
  id: string;
  label: string;
  adoptionRate?: number;
  publicTrust?: number;
  workforceDisplacementPressure?: number;
  retrainingCapacity?: number;
  politicalPolarization?: number;
  investmentMomentum?: number;
  educationalAdaptationSpeed?: number;
  mediaSentiment?: number;
  legalSystemFriction?: number;
  laborUnionResistance?: number;
  automationResistance?: number;
  institutionalAdaptationRate?: number;
  internationalCompetitionIntensity?: number;
  [key: string]: any;
}

export interface RiskTwin {
  id: string;
  label: string;
  riskCategory?: string;
  riskType?: string;
  severity: number;
  likelihood: number;
  mitigationEffectiveness?: number;
  publicAwareness?: number;
  regulatoryAttention?: number;
  systemicContagionRisk?: number;
  detectability?: number;
  mitigationReadiness?: number;
  [key: string]: any;
}

export interface AIEcosystemIndicators {
  capabilityFrontierIndex: number;
  safetyReadinessIndex: number;
  infrastructureStressIndex: number;
  governanceCoordinationIndex: number;
  ecosystemVolatilityIndex: number;
  [key: string]: any;
}

export interface AIEcosystemState {
  step?: number;
  initializedAtStep?: number;
  aiSystems: Record<string, AISystemTwin>;
  infrastructure: Record<string, InfrastructureTwin>;
  organizations: Record<string, OrganizationTwin>;
  dataEcosystems: Record<string, DataEcosystemTwin>;
  policies: Record<string, PolicyTwin>;
  humanInstitutions?: Record<string, HumanInstitutionTwin>;
  humanResponses?: Record<string, HumanInstitutionTwin>;
  risks: Record<string, RiskTwin>;
  indicators: AIEcosystemIndicators;
  scenarioWeights?: any;
  [key: string]: any;
}

export interface MechanismChange {
  targetId?: string;
  field?: string;
  oldValue?: any;
  newValue?: any;
  delta?: number;
  rationale?: string;
  twinKind?: string;
  twinId?: string;
  variable?: string;
  probability?: number;
  confidence?: number;
  causalAssumptions?: string[];
  uncertainty?: number;
  supportingEvidence?: string[];
  failureConditions?: string[];
  [key: string]: any;
}

export interface MechanismForecastContribution {
  mechanismType: string;
  summary: string;
  changes: MechanismChange[];
  disagreement?: number;
  [key: string]: any;
}

import { HRMWorldState, HRMNode, NodeId } from '../types/hrm';
import { createInitialAIEcosystemState } from './aiEcosystem';

export function createInitialWorldState(seed = 42, numNodes = 12, includeAIEcosystem = true): HRMWorldState {
  const nodes: Record<NodeId, HRMNode> = {};
  const labels = [
    'Perception Core', 'Memory Subsystem', 'Goal Evaluator', 'Uncertainty Regulator',
    'Arbitration Engine', 'Safety Guardrail', 'Resource Monitor', 'Consensus Ledger',
    'Adaptive Router', 'Reputation Tracker', 'Environment Interface', 'Execution VM'
  ];

  for (let i = 0; i < numNodes; i++) {
    const id = `node_${i}`;
    nodes[id] = {
      id,
      label: labels[i % labels.length],
      type: i % 2 === 0 ? 'cognitive' : 'infrastructure',
      value: 0.5 + (i * 0.02) % 0.3,
      baseline: 0.5,
      geometry: {
        x: Math.cos((i / numNodes) * Math.PI * 2) * 200,
        y: Math.sin((i / numNodes) * Math.PI * 2) * 200,
        z: 0,
      },
    };
  }

  const aiEcosystem = includeAIEcosystem ? createInitialAIEcosystemState(0) : undefined;

  return {
    step: 0,
    timestamp: Date.now(),
    activeGoal: 'Maintain World Model Stability & Maximize Benchmark Accuracy',
    globalStress: 0.15,
    globalEntropy: 0.12,
    attentionFocusNodeId: 'node_0',
    nodes,
    observation: { status: 'initialized', seed },
    aiEcosystem,
  };
}

export function freezeState(state: HRMWorldState): HRMWorldState {
  return JSON.parse(JSON.stringify(state));
}

export function computeStateHash(state: HRMWorldState): string {
  const str = JSON.stringify({
    step: state.step,
    stress: state.globalStress,
    entropy: state.globalEntropy,
    nodes: Object.keys(state.nodes).map(k => [k, state.nodes[k].value]),
  });
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return `hash_${Math.abs(hash).toString(16)}`;
}

import type { ARCColor, ARCExample, ARCGrid, ARCPuzzle } from '../types/arc';
import type {
  ARCStructuralFeatures,
  HieroCandidate,
  HieroCompatibilityResult,
  HieroExecutionMetrics,
  HieroGraph,
  HieroLedgerEvent,
} from '../types/hieromath';
import { gridsEqual, cellAccuracy, isValidARCGrid } from './arcEvaluation';
import { BinarySemanticLedger, HieroGraphBuilder, makeHieroObject, semanticSignature, validHieroObject } from './hieromath';

interface HieroARCContext {
  puzzle: ARCPuzzle;
  testInput: ARCGrid;
  trainingFeatures: ARCStructuralFeatures[];
  graph: HieroGraphBuilder;
}

interface HieroARCOperator {
  id: string;
  name: string;
  description: string;
  complexity: number;
  gamma(ctx: HieroARCContext): HieroCompatibilityResult;
  phi(grid: ARCGrid, ctx: HieroARCContext): ARCGrid;
  ruleSteps: string[];
  preservation: string[];
  changed: string[];
}

function shape(grid: ARCGrid | undefined): [number, number] {
  return grid && grid.length && grid[0]?.length ? [grid.length, grid[0].length] : [0, 0];
}

function outerFrameInfo(grid: ARCGrid): { uniform: boolean; color: number | null } {
  const rows = grid.length;
  const cols = grid[0].length;
  const color = grid[0][0];
  for (let c = 0; c < cols; c++) if (grid[0][c] !== color || grid[rows - 1][c] !== color) return { uniform: false, color: null };
  for (let r = 0; r < rows; r++) if (grid[r][0] !== color || grid[r][cols - 1] !== color) return { uniform: false, color: null };
  return { uniform: true, color };
}

function activeBoundingBox(grid: ARCGrid): [number, number, number, number] | undefined {
  let minR = grid.length, maxR = -1, minC = grid[0].length, maxC = -1;
  for (let r = 0; r < grid.length; r++) {
    for (let c = 0; c < grid[0].length; c++) {
      if (grid[r][c] !== 0) {
        minR = Math.min(minR, r); maxR = Math.max(maxR, r);
        minC = Math.min(minC, c); maxC = Math.max(maxC, c);
      }
    }
  }
  return maxR < 0 ? undefined : [minR, maxR, minC, maxC];
}

function deriveColorMap(input: ARCGrid, output: ARCGrid): { ok: boolean; map: Record<number, number> } {
  if (input.length !== output.length || input[0].length !== output[0].length) return { ok: false, map: {} };
  const map: Record<number, number> = {};
  for (let r = 0; r < input.length; r++) {
    for (let c = 0; c < input[0].length; c++) {
      const a = input[r][c];
      const b = output[r][c];
      if (map[a] !== undefined && map[a] !== b) return { ok: false, map: {} };
      map[a] = b;
    }
  }
  return { ok: true, map };
}

function changedCells(input: ARCGrid, output: ARCGrid | undefined): number {
  if (!output) return 0;
  const rows = Math.min(input.length, output.length);
  const cols = Math.min(input[0].length, output[0].length);
  let n = Math.abs(input.length * input[0].length - output.length * output[0].length);
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) if (input[r][c] !== output[r][c]) n++;
  return n;
}

export function extractStructuralFeatures(ex: ARCExample): ARCStructuralFeatures {
  const output = ex.output;
  const inShape = shape(ex.input);
  const outShape = shape(output);
  const frame = outerFrameInfo(ex.input);
  const rows = ex.input.length;
  const cols = ex.input[0].length;
  const fullUniformRows: Array<{ row: number; color: number }> = [];
  for (let r = 0; r < rows; r++) {
    const color = ex.input[r][0];
    if (ex.input[r].every(v => v === color) && color !== 0) fullUniformRows.push({ row: r, color });
  }
  let topLeftQuadrantOnly = true;
  const halfR = Math.ceil(rows / 2);
  const halfC = Math.ceil(cols / 2);
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if ((r >= halfR || c >= halfC) && ex.input[r][c] !== 0) topLeftQuadrantOnly = false;
    }
  }
  let colorMapConsistent = false;
  if (output) colorMapConsistent = deriveColorMap(ex.input, output).ok;
  return {
    inputShape: inShape,
    outputShape: output ? outShape : undefined,
    sameShape: Boolean(output && inShape[0] === outShape[0] && inShape[1] === outShape[1]),
    outputSmaller: Boolean(output && (outShape[0] < inShape[0] || outShape[1] < inShape[1])),
    outerFrameUniform: frame.uniform,
    outerFrameColor: frame.color,
    nonZeroCountInput: ex.input.flat().filter(v => v !== 0).length,
    nonZeroCountOutput: output?.flat().filter(v => v !== 0).length,
    colorMapConsistent,
    changedCells: changedCells(ex.input, output),
    activeBoundingBox: activeBoundingBox(ex.input),
    topLeftQuadrantOnly,
    hasFullUniformRow: fullUniformRows.length > 0,
    fullUniformRows,
  };
}

function allTrainingOutputs(puzzle: ARCPuzzle): ARCGrid[] {
  return puzzle.training.map(ex => ex.output).filter((g): g is ARCGrid => Boolean(g));
}

function evaluateCandidate(operator: HieroARCOperator, ctx: HieroARCContext): HieroCandidate {
  const predictedTrainingOutputs = ctx.puzzle.training.map(ex => operator.phi(ex.input, ctx));
  const predictedTestOutput = operator.phi(ctx.testInput, ctx);
  let exact = 0;
  let acc = 0;
  ctx.puzzle.training.forEach((ex, i) => {
    if (gridsEqual(predictedTrainingOutputs[i], ex.output)) exact++;
    acc += cellAccuracy(predictedTrainingOutputs[i], ex.output);
  });
  acc /= Math.max(1, ctx.puzzle.training.length);
  const confidence = exact === ctx.puzzle.training.length ? Math.max(0.75, 0.995 - operator.complexity * 0.01) : Math.min(0.65, acc / 100 * 0.7);
  const signature = semanticSignature({
    operator: operator.id,
    trainingExactMatches: exact,
    trainingCellAccuracy: Number(acc.toFixed(4)),
    predictedTestOutput,
  });
  return {
    operatorId: operator.id,
    name: operator.name,
    description: operator.description,
    predictedTrainingOutputs,
    predictedTestOutput,
    trainingExactMatches: exact,
    trainingCellAccuracy: Number(acc.toFixed(2)),
    confidence,
    complexity: operator.complexity,
    semanticSignature: signature,
    ruleSteps: operator.ruleSteps,
    preservation: operator.preservation,
    changed: operator.changed,
  };
}

function consistentGlobalColorMap(ctx: HieroARCContext): { ok: boolean; map: Record<number, number> } {
  const map: Record<number, number> = {};
  for (const ex of ctx.puzzle.training) {
    if (!ex.output || ex.input.length !== ex.output.length || ex.input[0].length !== ex.output[0].length) return { ok: false, map: {} };
    for (let r = 0; r < ex.input.length; r++) {
      for (let c = 0; c < ex.input[0].length; c++) {
        const a = ex.input[r][c]; const b = ex.output[r][c];
        if (map[a] !== undefined && map[a] !== b) return { ok: false, map: {} };
        map[a] = b;
      }
    }
  }
  return { ok: true, map };
}

const IdentityOperator: HieroARCOperator = {
  id: 'hm.identity',
  name: 'Identity / No Change',
  description: 'Preserve grid state exactly when training semantics indicate no transformation.',
  complexity: 1,
  gamma: ctx => {
    const outputs = allTrainingOutputs(ctx.puzzle);
    const exactIdentity = outputs.length === ctx.puzzle.training.length && ctx.puzzle.training.every((ex, i) => gridsEqual(ex.input, outputs[i]));
    return { ok: exactIdentity, reasons: exactIdentity ? ['Training pairs are invariant under identity.'] : ['Training pairs require changed state; identity is semantically contradicted.'], signature: 'identity-invariance', estimatedCellsAvoided: exactIdentity ? 0 : ctx.puzzle.training.reduce((n,e)=>n+e.input.length*e.input[0].length,0) };
  },
  phi: grid => grid.map(row => [...row]),
  ruleSteps: ['Preserve every cell and grid dimension.'],
  preservation: ['shape', 'cell-values', 'coordinates'],
  changed: [],
};

const ColorMapOperator: HieroARCOperator = {
  id: 'hm.color_map',
  name: 'Semantic Color Mapping',
  description: 'Apply a globally consistent color substitution while preserving grid topology.',
  complexity: 2,
  gamma: ctx => {
    const m = consistentGlobalColorMap(ctx);
    const changed = Object.entries(m.map).some(([a,b]) => Number(a) !== b);
    return { ok: m.ok && changed, reasons: m.ok && changed ? ['A single deterministic color map explains every training cell.'] : ['No non-trivial globally consistent color map exists.'], signature: semanticSignature(m), estimatedCellsAvoided: m.ok && changed ? 0 : ctx.puzzle.training.reduce((n,e)=>n+e.input.length*e.input[0].length,0) };
  },
  phi: (grid, ctx) => {
    const { map } = consistentGlobalColorMap(ctx);
    return grid.map(row => row.map(v => (map[v] ?? v) as ARCColor));
  },
  ruleSteps: ['Infer one color-to-color map from all training pairs.', 'Apply the map cellwise while preserving coordinates.'],
  preservation: ['shape', 'coordinates', 'background topology'],
  changed: ['color-content'],
};

const GravityOperator: HieroARCOperator = {
  id: 'hm.gravity_drop',
  name: 'Typed Downward Object Transport',
  description: 'Move color-2 objects to the lowest available row in the same column while preserving non-movable structure.',
  complexity: 3,
  gamma: ctx => {
    const sameShape = ctx.trainingFeatures.every(f => f.sameShape);
    const hasBarrier = ctx.trainingFeatures.every(f => f.fullUniformRows.some(x => x.color === 1));
    const color2Moved = ctx.puzzle.training.every(ex => {
      if (!ex.output) return false;
      const in2: Array<[number,number]> = [], out2: Array<[number,number]> = [];
      ex.input.forEach((row,r)=>row.forEach((v,c)=>{if(v===2) in2.push([r,c]);}));
      ex.output.forEach((row,r)=>row.forEach((v,c)=>{if(v===2) out2.push([r,c]);}));
      if (!in2.length || in2.length !== out2.length) return false;
      const inCols = in2.map(x=>x[1]).sort().join(','); const outCols = out2.map(x=>x[1]).sort().join(',');
      return inCols === outCols && out2.every(([r]) => r === ex.output!.length - 1);
    });
    const ok = sameShape && hasBarrier && color2Moved;
    return { ok, reasons: ok ? ['Color-2 object identity and columns are conserved; outputs place them on the bottom row while color-1 barrier structure is preserved.'] : ['Training semantics do not support downward color-2 transport.'], signature: 'transport:color2->bottom:column-preserving', estimatedCellsAvoided: ok ? 0 : ctx.puzzle.training.reduce((n,e)=>n+e.input.length*e.input[0].length,0) };
  },
  phi: grid => {
    const out = grid.map(row => [...row]);
    const cols = grid[0].length;
    for (let c = 0; c < cols; c++) {
      let count = 0;
      for (let r = 0; r < grid.length; r++) {
        if (out[r][c] === 2) { count++; out[r][c] = 0; }
      }
      for (let k = 0; k < count; k++) {
        for (let r = out.length - 1; r >= 0; r--) {
          if (out[r][c] === 0) { out[r][c] = 2; break; }
        }
      }
    }
    return out;
  },
  ruleSteps: ['Resolve color 2 as movable object and color 1 as preserved structure.', 'Remove movable objects from prior rows.', 'Commit each object to the lowest zero state in its original column.'],
  preservation: ['shape', 'object-count(color=2)', 'column-identity(color=2)', 'non-color2 structure'],
  changed: ['row-coordinate(color=2)'],
};

const DiagonalPropagationOperator: HieroARCOperator = {
  id: 'hm.diagonal_propagation',
  name: 'Diagonal Semantic Propagation',
  description: 'Propagate the off-diagonal members of the active 2x2 seed into their corresponding 4x4 diagonal channels.',
  complexity: 4,
  gamma: ctx => {
    const ok = ctx.puzzle.training.every(ex => {
      if (!ex.output || ex.input.length !== 4 || ex.input[0].length !== 4 || ex.output.length !== 4 || ex.output[0].length !== 4) return false;
      const inputOutsideSeedZero = ex.input.every((row,r)=>row.every((v,c)=> r < 2 && c < 2 ? true : v === 0));
      if (!inputOutsideSeedZero) return false;
      const a = ex.input[0][1], b = ex.input[1][0];
      const pred = ex.input.map(row=>[...row]);
      pred[1][2] = a; pred[2][1] = a; pred[0][3] = b; pred[3][0] = b;
      return gridsEqual(pred, ex.output);
    });
    return { ok, reasons: ok ? ['All non-zero source content is confined to a 2x2 seed and the same typed off-diagonal propagation rule reconstructs every training output.'] : ['Training pairs do not satisfy the 2x2 seed / 4x4 propagation invariant.'], signature: 'seed2x2:offdiag->paired-diagonal-channels', estimatedCellsAvoided: ok ? 0 : ctx.puzzle.training.reduce((n,e)=>n+e.input.length*e.input[0].length,0) };
  },
  phi: grid => {
    if (grid.length !== 4 || grid[0].length !== 4) return grid.map(row=>[...row]);
    const out = grid.map(row=>[...row]);
    const a = grid[0][1], b = grid[1][0];
    out[1][2] = a; out[2][1] = a; out[0][3] = b; out[3][0] = b;
    return out;
  },
  ruleSteps: ['Treat the upper-left 2x2 as the active seed object.', 'Preserve seed coordinates.', 'Propagate seed[0,1] into inner paired diagonal sites.', 'Propagate seed[1,0] into outer corner-linked sites.'],
  preservation: ['shape', 'seed-state', 'color-identity'],
  changed: ['previously-zero target coordinates'],
};

const BoundingBoxOperator: HieroARCOperator = {
  id: 'hm.bounding_box',
  name: 'Frame-Scoped Interior Extraction',
  description: 'Recognize a uniform enclosing frame and return only the semantically contained interior.',
  complexity: 2,
  gamma: ctx => {
    const ok = ctx.puzzle.training.every((ex,i) => {
      const f=ctx.trainingFeatures[i];
      if (!ex.output || !f.outerFrameUniform || !f.outputSmaller) return false;
      const expectedRows=ex.input.length-2, expectedCols=ex.input[0].length-2;
      return ex.output.length===expectedRows && ex.output[0].length===expectedCols;
    });
    return { ok, reasons: ok ? ['Uniform outer frame defines IN containment relation; training output is exactly the contained interior shape.'] : ['No consistent enclosing-frame containment relation.'], signature: 'IN(frame,interior)->extract(interior)', estimatedCellsAvoided: ok ? 0 : ctx.puzzle.training.reduce((n,e)=>n+e.input.length*e.input[0].length,0) };
  },
  phi: grid => {
    const info=outerFrameInfo(grid);
    if(!info.uniform || grid.length<3 || grid[0].length<3) return grid.map(row=>[...row]);
    return grid.slice(1,-1).map(row=>row.slice(1,-1));
  },
  ruleSteps: ['Resolve the uniform outer border as a Frame object.', 'Assert IN(interior, frame).', 'Transform by extracting only the contained interior state.'],
  preservation: ['interior cell order', 'interior color values'],
  changed: ['shape', 'frame removed'],
};

const RotationOperator: HieroARCOperator = {
  id: 'hm.rotate90',
  name: '90° Clockwise Rotation',
  description: 'Rotate the grid while preserving cell identities under a coordinate transport map.',
  complexity: 2,
  gamma: ctx => {
    const rotate=(g:ARCGrid):ARCGrid=>{
      const rows=g.length, cols=g[0].length; const out:ARCGrid=Array.from({length:cols},()=>Array(rows).fill(0));
      for(let r=0;r<rows;r++) for(let c=0;c<cols;c++) out[c][rows-1-r]=g[r][c]; return out;
    };
    const ok=ctx.puzzle.training.every(ex=>Boolean(ex.output && gridsEqual(rotate(ex.input),ex.output)));
    return {ok,reasons:ok?['A single 90-degree coordinate transport exactly preserves every training cell identity.']:['90-degree transport does not reconstruct training outputs.'],signature:'transport:rotate90',estimatedCellsAvoided:ok?0:ctx.puzzle.training.reduce((n,e)=>n+e.input.length*e.input[0].length,0)};
  },
  phi: grid => {
    const rows=grid.length, cols=grid[0].length; const out:ARCGrid=Array.from({length:cols},()=>Array(rows).fill(0));
    for(let r=0;r<rows;r++) for(let c=0;c<cols;c++) out[c][rows-1-r]=grid[r][c]; return out;
  },
  ruleSteps: ['Apply lossless coordinate transport (r,c) -> (c, rows-1-r).'],
  preservation: ['cell identities', 'cell count', 'color multiset'],
  changed: ['coordinates', 'shape when non-square'],
};

export const HIEROMATH_ARC_OPERATORS: HieroARCOperator[] = [
  IdentityOperator,
  ColorMapOperator,
  GravityOperator,
  DiagonalPropagationOperator,
  BoundingBoxOperator,
  RotationOperator,
];

export interface HieromathARCSolveResult {
  solverType: 'hieromath_hrm';
  puzzleId: string;
  predictedOutput: ARCGrid;
  committedHypothesis: {
    id: string;
    name: string;
    description: string;
    confidence: number;
    trainingExactMatches: number;
    trainingCellAccuracy: number;
    ruleSteps: string[];
    proposer: string;
    semanticSignature: string;
    preservation: string[];
    changed: string[];
  } | null;
  hypothesesLedger: Array<{
    id: string;
    name: string;
    description: string;
    confidence: number;
    trainingExactMatches: number;
    trainingCellAccuracy: number;
    ruleSteps: string[];
    proposer: string;
    semanticSignature: string;
    preservation: string[];
    changed: string[];
  }>;
  semanticGraph: HieroGraph;
  binarySemanticLedger: HieroLedgerEvent[];
  reasoningRounds: number;
  metrics: {
    startedAt: number;
    completedAt: number;
    latencyMs: number;
    apiCalls: number;
    reasoningRounds: number;
    inputTokens: number;
    outputTokens: number;
    totalTokens: number;
    hypothesesGenerated: number;
    hypothesesRejected: number;
    revisions: number;
    trainingExactMatch: boolean;
    validGrid: boolean;
    hieromath: HieroExecutionMetrics;
  };
}

export function solveARCWithHieromath(puzzle: ARCPuzzle, maxRounds = 40): HieromathARCSolveResult {
  const perf = typeof performance !== 'undefined' ? performance : { now: () => Date.now() };
  const start = perf.now();
  const startedAt = Date.now();
  const ledger = new BinarySemanticLedger();
  const graph = new HieroGraphBuilder();
  const testInput = puzzle.test[0]?.input;
  if (!testInput || !isValidARCGrid(testInput)) throw new Error('Invalid ARC test grid');

  const puzzleObj = graph.addNode(makeHieroObject(`puzzle:${puzzle.id}`, { name: puzzle.name, description: puzzle.description }, 'puzzle', 'arc_puzzle', ['root'], ['contains']));
  ledger.append('PARSED', 'parser.arc', [puzzleObj.I], 'ARC task parsed into Hieromathematical object graph.', { semanticSignature: semanticSignature(puzzleObj) });

  puzzle.training.forEach((ex, i) => {
    const inputObj = graph.addNode(makeHieroObject(`train:${puzzle.id}:${i}:input`, ex.input, 'grid.input.training', 'arc_grid', ['training','input'], ['observed']));
    const outputObj = graph.addNode(makeHieroObject(`train:${puzzle.id}:${i}:output`, ex.output, 'grid.output.training', 'arc_grid', ['training','output'], ['target']));
    graph.addRelation('IN', inputObj.I, puzzleObj.I);
    graph.addRelation('IN', outputObj.I, puzzleObj.I);
    graph.addRelation('TR', inputObj.I, outputObj.I, { role: 'training-example' });
  });
  const testObj = graph.addNode(makeHieroObject(`test:${puzzle.id}:input`, testInput, 'grid.input.test', 'arc_grid', ['test','input'], ['observed']));
  graph.addRelation('IN', testObj.I, puzzleObj.I);

  const trainingFeatures = puzzle.training.map(ex => extractStructuralFeatures(ex));
  trainingFeatures.forEach((f, i) => {
    const featureObj = graph.addNode(makeHieroObject(`features:${puzzle.id}:${i}`, f, 'structural.features', 'feature', ['derived'], ['diagnostic']));
    graph.addRelation('DEP', featureObj.I, `train:${puzzle.id}:${i}:input`);
    graph.addRelation('DEP', featureObj.I, `train:${puzzle.id}:${i}:output`);
  });
  ledger.append('RESOLVED', 'resolver.arc-structural-features', trainingFeatures.map((_,i)=>`features:${puzzle.id}:${i}`), 'Resolved shape, frame, color, movement, and active-region semantics before candidate execution.');

  const ctx: HieroARCContext = { puzzle, testInput, trainingFeatures, graph };
  const candidates: HieroCandidate[] = [];
  let pruned = 0;
  let kernels = 0;
  let estimatedCellsAvoided = 0;
  const roundLimit = Math.max(1, Math.min(40, Number.isFinite(maxRounds) ? Math.floor(maxRounds) : 40));
  let considered = 0;

  for (const operator of HIEROMATH_ARC_OPERATORS) {
    if (considered >= roundLimit) break;
    considered++;
    const opObj = graph.addNode(makeHieroObject(`operator:${operator.id}`, { name: operator.name, complexity: operator.complexity }, 'operator', 'mechanism', ['candidate'], ['transform']));
    graph.addRelation('DEP', opObj.I, puzzleObj.I, { role: 'candidate-rule' });

    const gamma = operator.gamma(ctx);
    if (!gamma.ok) {
      pruned++;
      estimatedCellsAvoided += gamma.estimatedCellsAvoided || 0;
      ledger.append('REJECTED_COMPATIBILITY', operator.id, [puzzleObj.I], gamma.reasons.join(' '), { gamma: 0, semanticSignature: gamma.signature });
      continue;
    }

    ledger.append('ACCEPTED_CANDIDATE', operator.id, [puzzleObj.I], gamma.reasons.join(' '), { gamma: 1, semanticSignature: gamma.signature, preservation: operator.preservation, changed: operator.changed });
    kernels++;
    const candidate = evaluateCandidate(operator, ctx);
    candidates.push(candidate);
    const candObj = graph.addNode(makeHieroObject(`candidate:${candidate.semanticSignature}`, candidate.predictedTestOutput, 'candidate.output', 'candidate', [operator.id], ['proposed']));
    candObj.provenance = { sourceIds: [testObj.I], ruleId: operator.id };
    graph.addRelation('TR', testObj.I, candObj.I, { operatorId: operator.id });
    graph.addRelation('CAUSE', opObj.I, candObj.I, { exactTraining: candidate.trainingExactMatches });

    if (candidate.trainingExactMatches === puzzle.training.length) {
      ledger.append('VERIFIED', operator.id, [candObj.I], 'Candidate reconstructs all declared training outputs exactly.', { trainingExactMatches: candidate.trainingExactMatches, trainingCellAccuracy: candidate.trainingCellAccuracy, semanticSignature: candidate.semanticSignature, preservation: candidate.preservation, changed: candidate.changed });
    } else {
      ledger.append('REJECTED_TRAINING', operator.id, [candObj.I], 'Candidate is semantically admissible but does not reconstruct all training examples.', { trainingExactMatches: candidate.trainingExactMatches, trainingCellAccuracy: candidate.trainingCellAccuracy, semanticSignature: candidate.semanticSignature });
    }
  }

  candidates.sort((a,b) => {
    if (b.trainingExactMatches !== a.trainingExactMatches) return b.trainingExactMatches - a.trainingExactMatches;
    if (b.trainingCellAccuracy !== a.trainingCellAccuracy) return b.trainingCellAccuracy - a.trainingCellAccuracy;
    if (a.complexity !== b.complexity) return a.complexity - b.complexity;
    return b.confidence - a.confidence;
  });

  let committed = candidates[0] || null;
  let predictedOutput: ARCGrid;
  if (committed) {
    predictedOutput = committed.predictedTestOutput;
    ledger.append('COMMITTED', committed.operatorId, [`candidate:${committed.semanticSignature}`], 'Highest-validity candidate committed transactionally after semantic compatibility and training verification.', { trainingExactMatches: committed.trainingExactMatches, trainingCellAccuracy: committed.trainingCellAccuracy, semanticSignature: committed.semanticSignature, preservation: committed.preservation, changed: committed.changed });
  } else {
    predictedOutput = testInput.map(row=>[...row]);
    ledger.append('FALLBACK', 'hm.fallback.identity', [testObj.I], 'No semantically admissible candidate survived; preserved test input without inventing a transformation.', { semanticSignature: semanticSignature(predictedOutput) });
  }

  const asHyp = (c: HieroCandidate) => ({
    id: `hyp_${c.operatorId}`,
    name: c.name,
    description: c.description,
    confidence: c.confidence,
    trainingExactMatches: c.trainingExactMatches,
    trainingCellAccuracy: c.trainingCellAccuracy,
    ruleSteps: c.ruleSteps,
    proposer: `Hieromathematics:${c.operatorId}`,
    semanticSignature: c.semanticSignature,
    preservation: c.preservation,
    changed: c.changed,
  });
  const graphSnapshot = graph.graph();
  const ledgerSnapshot = ledger.snapshot();
  // Enforce object validity as part of commit diagnostics.
  const semanticGraphValid = graphSnapshot.nodes.every(validHieroObject);
  const end = perf.now();
  const latencyMs = Math.round((end - start) * 1000) / 1000;
  const trainingExact = Boolean(committed && committed.trainingExactMatches === puzzle.training.length);

  return {
    solverType: 'hieromath_hrm',
    puzzleId: puzzle.id,
    predictedOutput,
    committedHypothesis: committed ? asHyp(committed) : null,
    hypothesesLedger: candidates.map(asHyp),
    semanticGraph: graphSnapshot,
    binarySemanticLedger: ledgerSnapshot,
    reasoningRounds: considered,
    metrics: {
      startedAt,
      completedAt: Date.now(),
      latencyMs,
      apiCalls: 0,
      reasoningRounds: considered,
      inputTokens: 0,
      outputTokens: 0,
      totalTokens: 0,
      hypothesesGenerated: candidates.length,
      hypothesesRejected: pruned + candidates.filter(c=>c.trainingExactMatches !== puzzle.training.length).length,
      revisions: 0,
      trainingExactMatch: trainingExact,
      validGrid: isValidARCGrid(predictedOutput) && semanticGraphValid,
      hieromath: {
        candidatesDeclared: Math.min(HIEROMATH_ARC_OPERATORS.length, roundLimit),
        candidatesPrunedBeforeCompute: pruned,
        kernelsExecuted: kernels,
        trainingPairsEvaluated: kernels * puzzle.training.length,
        estimatedCellsAvoided,
        ledgerEvents: ledgerSnapshot.length,
        semanticNodes: graphSnapshot.nodes.length,
        semanticRelations: graphSnapshot.relations.length,
      },
    },
  };
}

/**
 * Equal-capability conventional reference for controlled benchmarking.
 * It uses the exact same transformation inventory as the Hieromathematics path,
 * but does not perform Gamma semantic pruning, build a semantic graph, or ledger
 * rejected candidates. Every numerical transformation is evaluated.
 */
export function solveARCBruteForceReference(puzzle: ARCPuzzle): {
  predictedOutput: ARCGrid;
  committed: HieroCandidate | null;
  candidates: HieroCandidate[];
  kernelsExecuted: number;
} {
  const testInput = puzzle.test[0]?.input;
  if (!testInput || !isValidARCGrid(testInput)) throw new Error('Invalid ARC test grid');
  const ctx: HieroARCContext = {
    puzzle,
    testInput,
    trainingFeatures: puzzle.training.map(ex => extractStructuralFeatures(ex)),
    graph: new HieroGraphBuilder(),
  };
  const candidates = HIEROMATH_ARC_OPERATORS.map(op => evaluateCandidate(op, ctx));
  candidates.sort((a,b) => {
    if (b.trainingExactMatches !== a.trainingExactMatches) return b.trainingExactMatches - a.trainingExactMatches;
    if (b.trainingCellAccuracy !== a.trainingCellAccuracy) return b.trainingCellAccuracy - a.trainingCellAccuracy;
    if (a.complexity !== b.complexity) return a.complexity - b.complexity;
    return b.confidence - a.confidence;
  });
  const committed = candidates[0] || null;
  return {
    predictedOutput: committed ? committed.predictedTestOutput : testInput.map(row=>[...row]),
    committed,
    candidates,
    kernelsExecuted: candidates.length,
  };
}

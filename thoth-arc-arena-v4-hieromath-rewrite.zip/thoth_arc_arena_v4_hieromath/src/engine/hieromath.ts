import type {
  HieroObject,
  HieroGraph,
  HieroRelation,
  HieroRelationCode,
  HieroLedgerEvent,
  HieroLedgerStatus,
} from '../types/hieromath';

export function canonicalize(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(canonicalize);
  if (value && typeof value === 'object') {
    const obj = value as Record<string, unknown>;
    const out: Record<string, unknown> = {};
    for (const key of Object.keys(obj).sort()) out[key] = canonicalize(obj[key]);
    return out;
  }
  return value;
}

export function semanticSignature(value: unknown): string {
  // FNV-1a 32-bit over canonical JSON. Not cryptographic; stable and portable.
  const text = JSON.stringify(canonicalize(value));
  let hash = 0x811c9dc5;
  for (let i = 0; i < text.length; i++) {
    hash ^= text.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return `hm-${hash.toString(16).padStart(8, '0')}`;
}

export function validHieroObject(h: HieroObject): boolean {
  return Boolean(
    h.I &&
    h.V !== undefined && h.V !== null &&
    h.C?.domain &&
    h.C?.type &&
    h.B &&
    h.S &&
    h.G?.schema &&
    h.S.valid &&
    h.S.bounded &&
    h.S.constraintSatisfied
  );
}

export function makeHieroObject<T>(
  identity: string,
  value: T,
  type: string,
  kind: HieroObject['G']['kind'],
  tags: string[] = [],
  behavior: string[] = ['readable'],
  mutable = false,
): HieroObject<T> {
  return {
    I: identity,
    V: value,
    C: {
      domain: 'ARC',
      type,
      scope: 'puzzle-local',
      constraints: ['finite-grid', 'integer-colors-0-9'],
      tags,
    },
    B: { classes: behavior, mutable },
    S: {
      valid: true,
      active: true,
      bounded: true,
      constraintSatisfied: true,
      deterministic: true,
    },
    G: { kind, schema: `hieromath.arc.${type}`, version: 1 },
  };
}

export class HieroGraphBuilder {
  private nodesById = new Map<string, HieroObject>();
  private rels: HieroRelation[] = [];
  private relSeq = 0;

  addNode<T>(node: HieroObject<T>): HieroObject<T> {
    this.nodesById.set(node.I, node as HieroObject);
    return node;
  }

  addRelation(r: HieroRelationCode, from: string, to: string, kappa?: Record<string, unknown>): void {
    this.rels.push({ id: `rel-${++this.relSeq}`, r, from, to, kappa });
  }

  graph(): HieroGraph {
    return { nodes: Array.from(this.nodesById.values()), relations: [...this.rels] };
  }
}

export class BinarySemanticLedger {
  private events: HieroLedgerEvent[] = [];

  append(
    status: HieroLedgerStatus,
    operatorId: string,
    objectIds: string[],
    reason: string,
    extras: Partial<Omit<HieroLedgerEvent, 'sequence' | 'status' | 'operatorId' | 'objectIds' | 'reason' | 'timestampLogical'>> = {},
  ): HieroLedgerEvent {
    const event: HieroLedgerEvent = {
      sequence: this.events.length + 1,
      status,
      operatorId,
      objectIds,
      reason,
      timestampLogical: this.events.length + 1,
      ...extras,
    };
    this.events.push(event);
    return event;
  }

  snapshot(): HieroLedgerEvent[] {
    return this.events.map(e => ({ ...e, objectIds: [...e.objectIds] }));
  }
}

import { performance } from 'node:perf_hooks';
import { writeFileSync } from 'node:fs';
import { BUNDLED_ARC_PUZZLES } from '../src/engine/arcDataset';
import { ALL_ARC_MECHANISMS } from '../src/engine/arcMechanisms';
import { gridsEqual, cellAccuracy } from '../src/engine/arcEvaluation';
import { solveARCBruteForceReference, solveARCWithHieromath } from '../src/engine/hieromathArc';
import type { ARCPuzzle } from '../src/types/arc';

function solveLegacyLocal(puzzle: ARCPuzzle) {
  const ledger: any[] = [];
  const testInput = puzzle.test[0].input;
  for (const mech of ALL_ARC_MECHANISMS) ledger.push(...mech.propose({ training: puzzle.training, testInput }));
  ledger.sort((a,b) => (b.trainingExactMatches-a.trainingExactMatches) || ((b.trainingCellAccuracy||0)-(a.trainingCellAccuracy||0)) || (b.confidence-a.confidence));
  return ledger[0]?.predictedTestOutput || testInput;
}

function summarize(kind: string, solve: (p: ARCPuzzle)=>any) {
  const rows = BUNDLED_ARC_PUZZLES.map(p => {
    const raw = solve(p);
    const predicted = raw.predictedOutput || raw;
    const expected = p.test[0].expectedOutput!;
    return { id:p.id, name:p.name, exact:gridsEqual(predicted, expected), cellAccuracy:cellAccuracy(predicted, expected), raw };
  });
  return { kind, exactSolved:rows.filter(r=>r.exact).length, exactRate:rows.filter(r=>r.exact).length/rows.length, meanCellAccuracy:rows.reduce((a,r)=>a+r.cellAccuracy,0)/rows.length, rows };
}

function time(label:string, solve:(p:ARCPuzzle)=>any, iterations=25000) {
  let checksum=0;
  const t0=performance.now();
  for(let i=0;i<iterations;i++) for(const p of BUNDLED_ARC_PUZZLES) {
    const raw=solve(p); const predicted=raw.predictedOutput || raw; checksum += predicted.length;
  }
  const totalMs=performance.now()-t0;
  return { label, iterations, totalSolves:iterations*BUNDLED_ARC_PUZZLES.length, totalMs, msPerSolve:totalMs/(iterations*BUNDLED_ARC_PUZZLES.length), checksum };
}

const legacy=summarize('legacy-local-mechanism-inventory', p=>solveLegacyLocal(p));
const equalCapability=summarize('equal-capability-conventional-bruteforce', p=>solveARCBruteForceReference(p));
const hieromath=summarize('hieromath-validate-before-compute', p=>solveARCWithHieromath(p,40));
const output={
  note:'Wall-clock on tiny bundled ARC tasks is dominated by orchestration overhead; kernel-count savings should not be presented as a speedup without larger controlled tasks.',
  accuracy:{legacy,equalCapability,hieromath},
  timing:{
    legacy:time('legacy',p=>solveLegacyLocal(p)),
    equalCapability:time('equal-capability-bruteforce',p=>solveARCBruteForceReference(p)),
    hieromath:time('hieromath',p=>solveARCWithHieromath(p,40)),
  },
  semanticWork:BUNDLED_ARC_PUZZLES.map(p=>{
    const r=solveARCWithHieromath(p,40);
    return {puzzleId:p.id,...r.metrics.hieromath};
  })
};
writeFileSync('benchmark_hieromath.json',JSON.stringify(output,null,2));
console.log(JSON.stringify(output,null,2));
